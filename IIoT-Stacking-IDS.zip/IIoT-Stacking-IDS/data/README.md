# Dataset Documentation & Data Availability Guide

This directory details the dataset sources, feature schema, pre-extraction protocol, and leakage-safe partitioning utilized in the revised manuscript:

> **Multi-Objective Feature Selection and a Diversity-Driven Heterogeneous Stacking Ensemble for Low-Latency Attack Detection in Industrial IoT**  
> *IEEE Internet of Things Journal* (Manuscript ID: **IoT-72745-2026**)  
> Authors: Jeeva Arumugam and Dr. Nagarajan Ramalingam

---

## 1. Primary Data Source & Availability Statement

The empirical evaluations in this research are conducted on the **DataSense Industrial IoT Benchmark Dataset (2025/2026)**, developed and released by the **Canadian Institute for Cybersecurity (CIC)** at the **University of New Brunswick (UNB)**.

- **Official Repository & Download Portal:**  
  [https://www.unb.ca/cic/datasets/iiot-dataset-2025.html](https://www.unb.ca/cic/datasets/iiot-dataset-2025.html)
- **Data License:**  
  Creative Commons Attribution 4.0 International (CC BY 4.0). Open for academic, non-commercial, and reproducible scientific research.
- **Physical Testbed Infrastructure:**  
  The dataset was captured from a live Industrial IoT testbed encompassing **38 distinct physical edge devices** (industrial programmable logic controllers [PLCs], IP cameras, edge routers, smart power switches, environment sensors, and edge gateways) interacting across multi-protocol environments (MQTT, Modbus, CoAP, TCP/IP, UDP, ICMP).

---

## 2. Dataset Composition & Curation

| Split / Pool Name | Total Records | Class Distribution | Device Diversity | Primary Scientific Purpose |
|---|---|---|---|---|
| **Raw Packet Captures** | 227,191 records | Natural operational capture | 38 physical devices | Full initial network capture |
| **Data Integrity Filtering** | -10,685 records (4.7%) | Corrupted / malformed packets | Excluded | Purged unparseable records |
| **Clean Curated Pool** | 216,506 records | 181,433 Attack / 35,073 Benign | 38 physical devices | Base pool for partitioning |
| **Frozen Benchmark Pool** | **26,506 records** | **13,253 Benign (50%) / 13,253 Attack (50%)** | 38 devices (140 blocks) | **5-fold leakage-safe nested CV** |
| **Fresh Evaluation Pool** | **190,000 records** | **30,780 Benign (16.2%) / 159,220 Attack (83.8%)** | 38 devices | **Out-of-distribution transferability** |

### Benchmark Pool Pre-Extraction (`data/benchmark/`)
To enable immediate, zero-barrier replication of all 5-fold cross-validation experiments without requiring users to download and process 50+ GB of raw PCAP captures, this repository provides the pre-extracted 14-feature matrix directly:

- `X_bench.pkl`: 26,506 samples $	imes$ 14 NSGA-II features (Pandas DataFrame, float64).
- `y_bench.pkl`: 26,506 binary ground-truth labels (0 = Benign, 1 = Attack).
- `groups_bench.npy`: 26,506 composite grouping keys (`scenario_block_id` $	imes$ `device_mac`).
- `cv_folds_bench_pos.pkl`: List of 5 tuples `(train_indices, val_indices)` guaranteeing zero group overlap.

---

## 3. The 14 NSGA-II Selected Features

Out of 204 candidate flow, window, and temporal features engineered from raw traffic, tri-objective NSGA-II optimization isolated the following 14 features at the Pareto knee point:

| No. | Feature Name | Domain | Aggregation / Window | Physical Security Interpretation |
|---|---|---|---|---|
| 01 | `network_packets_all_count_rollq75_10` | Volume | 10-step rolling 75th percentile | Sustained burst packet generation in volumetric flood attacks |
| 02 | `network_ttl_avg_rollmean5` | Header | 5-step rolling mean TTL | Anomaly in hop count indicating spoofed/external routing |
| 03 | `network_packets_all_count_device_relative_z` | Anomaly | Device-level z-score standardization | Device-relative traffic deviation from historical baseline |
| 04 | `network_packets_all_count_rollstd5` | Volume | 5-step rolling standard deviation | Volatility and jitter in packet transmission frequency |
| 05 | `network_ttl_avg` | Header | Instantaneous mean TTL | Instantaneous IP Time-To-Live header value |
| 06 | `network_packets_all_count_log1p` | Volume | $\log(1 + x)$ transformed packet count | Log-scaled total flow packet volume |
| 07 | `network_packet-size_avg` | Size | Flow average packet size (bytes) | Byte distribution anomalies (e.g. oversized payloads or empty packets) |
| 08 | `network_packet-size_min` | Size | Minimum observed packet size (bytes) | Small packet footprints indicative of probe or SYN flood scans |
| 09 | `network_window-size_range` | TCP | $\max(\text{window}) - \min(\text{window})$ | TCP sliding window dynamics and buffer pressure |
| 10 | `network_ports_src_count_log1p` | Topology | $\log(1 + x)$ distinct source ports | Multi-port scanning and ephemeral port rotation |
| 11 | `network_ip-length_std_deviation_log1p` | Size | Standard deviation of IP packet length | Length heterogeneity indicating payload padding or fragmentation |
| 12 | `network_window-size_std_deviation` | TCP | Standard deviation of TCP window size | Instability in receiver window negotiation |
| 13 | `network_packet-size_max_log1p` | Size | $\log(1 + x)$ maximum packet size | Maximum payload boundary detection |
| 14 | `network_tcp-flags_std_deviation` | Control | Standard deviation of TCP flag bits | Irregular combinations of SYN, FIN, ACK, RST, PSH flags |

---

## 4. Leakage-Safe Group Partitioning Protocol (Algorithm 1)

Standard random splitting allows identical physical devices or continuous attack bursts to appear in both training and test sets, artificially inflating MCC by up to $+1.0258$ (as proven in Section IV-D of the paper). 

To prevent this:
1. Every record is assigned a composite key: $g = \text{device\_mac} \parallel \text{scenario\_block\_id} \parallel \text{capture\_day}$.
2. A total of **140 unique groups** are partitioned across 5 folds such that:
   $$\text{train\_groups}_k \cap \text{val\_groups}_k = \emptyset \quad \forall k \in \{1, 2, 3, 4, 5\}$$
3. This is verified by running:
   ```bash
   python scripts/01_verify_leakage_safe_partitioning.py
   ```
