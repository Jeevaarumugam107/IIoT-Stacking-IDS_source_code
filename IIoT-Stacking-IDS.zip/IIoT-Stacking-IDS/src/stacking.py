"""
Diversity-Driven Heterogeneous Stacking Ensemble and Pairwise Metrics
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
from sklearn.base import BaseEstimator, ClassifierMixin

def compute_yules_q(y_true, y_pred1, y_pred2):
    """
    Computes pairwise Yule's Q statistic between two models' binary predictions.
    Q in [-1, +1]. Negative or lower values indicate higher diversity.
    """
    c1 = (y_pred1 == y_true).astype(int)
    c2 = (y_pred2 == y_true).astype(int)
    
    N11 = np.sum((c1 == 1) & (c2 == 1))
    N00 = np.sum((c1 == 0) & (c2 == 0))
    N10 = np.sum((c1 == 1) & (c2 == 0))
    N01 = np.sum((c1 == 0) & (c2 == 1))
    
    det = N11 * N00 - N01 * N10
    denom = N11 * N00 + N01 * N10
    return det / denom if denom > 0 else 0.0

def compute_disagreement(y_true, y_pred1, y_pred2):
    """Computes pairwise disagreement metric."""
    c1 = (y_pred1 == y_true).astype(int)
    c2 = (y_pred2 == y_true).astype(int)
    return np.mean(c1 != c2)

def compute_double_fault(y_true, y_pred1, y_pred2):
    """Computes pairwise double fault ratio."""
    c1 = (y_pred1 == y_true).astype(int)
    c2 = (y_pred2 == y_true).astype(int)
    return np.mean((c1 == 0) & (c2 == 0))

def compute_all_diversity_matrices(y_true, preds_dict):
    """
    Computes diversity matrices for all pairs of models.
    """
    models = list(preds_dict.keys())
    m = len(models)
    Q = np.zeros((m, m))
    Dis = np.zeros((m, m))
    DF = np.zeros((m, m))
    
    for i in range(m):
        for j in range(m):
            if i == j:
                Q[i, j] = 1.0
                Dis[i, j] = 0.0
                DF[i, j] = np.mean((preds_dict[models[i]] != y_true).astype(int))
            else:
                Q[i, j] = compute_yules_q(y_true, preds_dict[models[i]], preds_dict[models[j]])
                Dis[i, j] = compute_disagreement(y_true, preds_dict[models[i]], preds_dict[models[j]])
                DF[i, j] = compute_double_fault(y_true, preds_dict[models[i]], preds_dict[models[j]])
                
    return models, Q, Dis, DF

def greedy_diversity_selection(models, Q_matrix, k=4):
    """
    Greedy forward selection minimizing average pairwise Yule's Q.
    Starts with index 0 (top-performing standalone model) and iteratively adds
    the candidate with lowest average association with already selected pool.
    """
    selected = [0]
    while len(selected) < k:
        candidates = [c for c in range(len(models)) if c not in selected]
        best_cand = None
        min_avg_q = float("inf")
        for cand in candidates:
            avg_q = np.mean([Q_matrix[cand, s] for s in selected])
            if avg_q < min_avg_q:
                min_avg_q = avg_q
                best_cand = cand
        selected.append(best_cand)
    return [models[i] for i in selected]

class DiversityStackingClassifier(BaseEstimator, ClassifierMixin):
    """
    Heterogeneous Stacking Classifier with uncalibrated Logistic Regression meta-learner.
    """
    def __init__(self, base_models, C=0.1, penalty="l2", random_state=42):
        self.base_models = base_models
        self.C = C
        self.penalty = penalty
        self.random_state = random_state
        self.meta_learner = LogisticRegression(C=C, penalty=penalty, solver="lbfgs", random_state=random_state)
        
    def fit_from_oof(self, oof_probabilities, y_true):
        """
        Fits meta-learner on out-of-fold probability matrix.
        oof_probabilities: array of shape (N, n_models)
        """
        self.meta_learner.fit(oof_probabilities, y_true)
        return self

    def predict_proba(self, meta_features):
        return self.meta_learner.predict_proba(meta_features)

    def predict(self, meta_features, threshold=0.5):
        probas = self.predict_proba(meta_features)[:, 1]
        return (probas >= threshold).astype(int)
