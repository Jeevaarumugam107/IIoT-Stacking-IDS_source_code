"""
Statistical Significance Testing: Group Permutation & Paired Bootstrap Tests
"""

import numpy as np
from sklearn.metrics import matthews_corrcoef, roc_auc_score

def group_permutation_test(y_true, preds_a, preds_b, groups, n_resamples=1000, seed=42):
    """
    Performs group-level permutation test preserving dependency structures.
    Randomly swaps entire groups between Model A and Model B under null hypothesis.
    """
    rng = np.random.RandomState(seed)
    y_true = np.asarray(y_true)
    preds_a = np.asarray(preds_a)
    preds_b = np.asarray(preds_b)
    groups = np.asarray(groups)
    
    orig_diff = matthews_corrcoef(y_true, preds_a) - matthews_corrcoef(y_true, preds_b)
    unique_groups = np.unique(groups)
    
    null_diffs = []
    for _ in range(n_resamples):
        swap_mask = rng.rand(len(unique_groups)) < 0.5
        swapped_groups = set(unique_groups[swap_mask])
        
        sample_a = preds_a.copy()
        sample_b = preds_b.copy()
        
        in_swapped = np.isin(groups, list(swapped_groups))
        sample_a[in_swapped] = preds_b[in_swapped]
        sample_b[in_swapped] = preds_a[in_swapped]
        
        diff = matthews_corrcoef(y_true, sample_a) - matthews_corrcoef(y_true, sample_b)
        null_diffs.append(diff)
        
    null_diffs = np.array(null_diffs)
    p_value = np.mean(np.abs(null_diffs) >= np.abs(orig_diff))
    return float(orig_diff), float(p_value), null_diffs

def paired_bootstrap_test(y_true, preds_a, preds_b, n_resamples=2000, seed=42):
    """
    Performs paired bootstrap resampling (B=2,000) over out-of-fold instances.
    Computes empirical difference, 95% Confidence Interval, and paired p-value.
    """
    rng = np.random.RandomState(seed)
    y_true = np.asarray(y_true)
    preds_a = np.asarray(preds_a)
    preds_b = np.asarray(preds_b)
    n = len(y_true)
    
    orig_diff = matthews_corrcoef(y_true, preds_a) - matthews_corrcoef(y_true, preds_b)
    boot_diffs = []
    
    for _ in range(n_resamples):
        idx = rng.randint(0, n, size=n)
        mcc_a = matthews_corrcoef(y_true[idx], preds_a[idx])
        mcc_b = matthews_corrcoef(y_true[idx], preds_b[idx])
        boot_diffs.append(mcc_a - mcc_b)
        
    boot_diffs = np.array(boot_diffs)
    ci_lower = np.percentile(boot_diffs, 2.5)
    ci_upper = np.percentile(boot_diffs, 97.5)
    p_value = 2.0 * min(np.mean(boot_diffs <= 0), np.mean(boot_diffs >= 0))
    p_value = max(p_value, 1.0 / n_resamples)
    
    return float(orig_diff), float(ci_lower), float(ci_upper), float(p_value)
