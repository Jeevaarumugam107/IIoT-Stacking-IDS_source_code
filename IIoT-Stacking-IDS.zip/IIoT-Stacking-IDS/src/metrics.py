"""
Evaluation Metrics: MCC, AUROC, AUPRC, F1, Balanced Accuracy, ECE, Brier
"""

import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    balanced_accuracy_score, matthews_corrcoef, roc_auc_score,
    average_precision_score, brier_score_loss, confusion_matrix
)

def expected_calibration_error(y_true, y_proba, n_bins=10):
    """
    Computes Expected Calibration Error (ECE) with equal-width probability bins.
    """
    y_true = np.asarray(y_true)
    y_proba = np.asarray(y_proba)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    bin_ids = np.digitize(y_proba, bins[1:-1])
    
    ece = 0.0
    total_samples = len(y_true)
    for b in range(n_bins):
        mask = (bin_ids == b)
        bin_count = np.sum(mask)
        if bin_count > 0:
            bin_acc = np.mean(y_true[mask])
            bin_conf = np.mean(y_proba[mask])
            ece += (bin_count / total_samples) * np.abs(bin_acc - bin_conf)
    return float(ece)

def compute_all_metrics(y_true, y_pred, y_proba=None):
    """
    Calculates comprehensive performance metrics for binary intrusion detection.
    """
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    
    res = {
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "specificity": float(specificity),
        "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn)
    }
    
    if y_proba is not None:
        try:
            res["auroc"] = float(roc_auc_score(y_true, y_proba))
        except Exception:
            res["auroc"] = 0.5
        try:
            res["auprc"] = float(average_precision_score(y_true, y_proba))
        except Exception:
            res["auprc"] = 0.5
        res["brier"] = float(brier_score_loss(y_true, y_proba))
        res["ece"] = expected_calibration_error(y_true, y_proba, n_bins=10)
        
    return res
