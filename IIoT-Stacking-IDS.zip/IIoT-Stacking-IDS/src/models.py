"""
Classical ML Estimators and Deep Learning Architectures
"""

import torch
import torch.nn as nn
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier

def get_classical_baselines(seed=42):
    """
    Returns configured dictionary of classical machine learning baselines.
    """
    models = {
        "rbf_svm": SVC(C=10.0, gamma="scale", class_weight="balanced", probability=True, random_state=seed),
        "lightgbm": LGBMClassifier(num_leaves=15, n_estimators=300, random_state=seed, verbose=-1, n_jobs=-1),
        "random_forest": RandomForestClassifier(n_estimators=300, max_depth=8, random_state=seed, n_jobs=-1),
        "catboost": CatBoostClassifier(iterations=300, depth=6, random_state=seed, verbose=False),
        "extra_trees": ExtraTreesClassifier(n_estimators=300, max_depth=8, random_state=seed, n_jobs=-1),
        "xgboost": XGBClassifier(max_depth=6, n_estimators=100, learning_rate=0.1, random_state=seed, eval_metric="logloss"),
        "linear_svm": SVC(kernel="linear", C=0.1, class_weight="balanced", probability=True, random_state=seed),
        "logistic_regression": LogisticRegression(C=1.0, solver="lbfgs", max_iter=500, random_state=seed),
        "knn": KNeighborsClassifier(n_neighbors=31, weights="uniform", n_jobs=-1)
    }
    return models

# ------------------------------------------------------------------------------
# Deep Learning PyTorch Architectures
# ------------------------------------------------------------------------------
class MLPNet(nn.Module):
    def __init__(self, in_features=14, hidden1=128, hidden2=64, dropout=0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_features, hidden1),
            nn.BatchNorm1d(hidden1),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden1, hidden2),
            nn.BatchNorm1d(hidden2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden2, 1)
        )
    def forward(self, x):
        return self.net(x).squeeze(1)

class BiGRUNet(nn.Module):
    def __init__(self, in_features=14, hidden_size=64, num_layers=2, dropout=0.2):
        super().__init__()
        self.gru = nn.GRU(
            input_size=1,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0
        )
        self.fc = nn.Sequential(
            nn.Linear(hidden_size * 2, 32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, 1)
        )
    def forward(self, x):
        x = x.unsqueeze(-1)
        out, _ = self.gru(x)
        out = out[:, -1, :]
        return self.fc(out).squeeze(1)

class LightweightTransformer(nn.Module):
    def __init__(self, in_features=14, d_model=32, nhead=4, num_layers=2, dim_feedforward=64, dropout=0.1):
        super().__init__()
        self.in_proj = nn.Linear(1, d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.fc = nn.Sequential(
            nn.Linear(d_model * in_features, 32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, 1)
        )
    def forward(self, x):
        x = x.unsqueeze(-1)
        x = self.in_proj(x)
        out = self.transformer(x)
        out = out.reshape(out.size(0), -1)
        return self.fc(out).squeeze(1)
