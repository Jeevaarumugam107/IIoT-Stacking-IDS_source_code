"""
Dataset Ingestion, Metadata Parsing, and Group-Disjoint Fold Verification
"""

import os
import pickle
import numpy as np
import pandas as pd

FEATURE_NAMES = [
    "network_packets_all_count_rollq75_10",
    "network_ttl_avg_rollmean5",
    "network_packets_all_count_device_relative_z",
    "network_packets_all_count_rollstd5",
    "network_ttl_avg",
    "network_packets_all_count_log1p",
    "network_packet-size_avg",
    "network_packet-size_min",
    "network_window-size_range",
    "network_ports_src_count_log1p",
    "network_ip-length_std_deviation_log1p",
    "network_window-size_std_deviation",
    "network_packet-size_max_log1p",
    "network_tcp-flags_std_deviation"
]

def load_benchmark_data(data_dir=None):
    """
    Loads pre-extracted 14-feature benchmark matrix, labels, grouping keys, and fold splits.
    """
    if data_dir is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        data_dir = os.path.join(base_dir, "data", "benchmark")
        
    X_path = os.path.join(data_dir, "X_bench.pkl")
    y_path = os.path.join(data_dir, "y_bench.pkl")
    groups_path = os.path.join(data_dir, "groups_bench.npy")
    folds_path = os.path.join(data_dir, "cv_folds_bench_pos.pkl")
    
    X = pd.read_pickle(X_path)
    y = pd.read_pickle(y_path).values.astype(int)
    groups = np.load(groups_path, allow_pickle=True)
    with open(folds_path, "rb") as f:
        folds = pickle.load(f)
        
    return X, y, groups, folds

def verify_group_disjointness(groups, folds):
    """
    Verifies zero scenario-device group overlap between train and validation folds.
    """
    overlaps = []
    for k, (train_idx, val_idx) in enumerate(folds):
        train_groups = set(groups[train_idx])
        val_groups = set(groups[val_idx])
        overlap = train_groups.intersection(val_groups)
        overlaps.append(len(overlap))
        assert len(overlap) == 0, f"Leakage detected in Fold {k+1}: {len(overlap)} overlapping groups!"
    return overlaps
