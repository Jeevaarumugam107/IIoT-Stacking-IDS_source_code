"""
SHAP Explainability & Root-Cause Failure Analysis
"""

import numpy as np
import pandas as pd
import shap

def explain_tree_model(model, X_sample, feature_names=None):
    """
    Calculates TreeSHAP values for tree-based ensemble members.
    """
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_sample)
    if isinstance(shap_values, list) and len(shap_values) == 2:
        shap_values = shap_values[1]
    df_shap = pd.DataFrame(shap_values, columns=feature_names)
    return explainer, df_shap

def diagnose_device_shift(X_benign, X_fresh, feature_name):
    """
    Computes distribution shift metrics (mean ratio, Kolmogorov-Smirnov)
    for a specific feature across baseline and fresh operational splits.
    """
    val_bench = X_benign[feature_name].values
    val_fresh = X_fresh[feature_name].values
    
    mean_bench = np.mean(val_bench)
    mean_fresh = np.mean(val_fresh)
    ratio = mean_fresh / (mean_bench + 1e-12)
    return {
        "feature": feature_name,
        "mean_benchmark": float(mean_bench),
        "mean_fresh": float(mean_fresh),
        "shift_ratio": float(ratio)
    }
