"""
IIoT-Stacking-IDS: Multi-Objective Feature Selection & Diversity-Driven Stacking
Official Reproducibility Package for IEEE Internet of Things Journal (IoT-72745-2026)
"""

__version__ = "2.0.0"
__author__ = "Jeeva Arumugam and Dr. Nagarajan Ramalingam"
