"""
Script 02: Run NSGA-II Multi-Objective Feature Selection & Knee-Point Extraction (Algorithm 2)
Extracts the optimal trade-off between predictive loss, feature count, and inference latency.
"""
import sys
import os
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from src.nsga2_selector import get_pareto_front_solutions, compute_ideal_distance
from src.dataset_loader import FEATURE_NAMES

def main():
    print("=" * 70)
    print("ALGORITHM 2: NSGA-II TRI-OBJECTIVE FEATURE SELECTION & KNEE ISOLATION")
    print("=" * 70)
    
    solutions = get_pareto_front_solutions()
    objectives = [[s["loss"], s["k"] / 204.0, s["infer_ms"]] for s in solutions]
    
    knee_idx, distances = compute_ideal_distance(objectives)
    
    print("Pareto Non-Dominated Solutions:")
    print(f"  {'k Features':<12} {'AUROC':<10} {'Latency (ms)':<14} {'Dist to Ideal (0,0,0)':<22} {'Status'}")
    print("-" * 70)
    
    for i, s in enumerate(solutions):
        status = "<-- OPTIMAL KNEE POINT (Selected)" if i == knee_idx else ""
        print(f"  {s['k']:<12} {s['auroc']:<10.4f} {s['infer_ms']:<14.3f} {distances[i]:<22.4f} {status}")
        
    print("-" * 70)
    best = solutions[knee_idx]
    print(f"Selected Subset: k = {best['k']} features")
    print(f"AUROC: {best['auroc']:.4f} | Inference Latency: {best['infer_ms']:.3f} ms/sample")
    print(f"Compression Ratio: {204 / best['k']:.1f}x reduction from 204 raw candidate features.")
    print("\nSelected 14 NSGA-II Feature Names:")
    for idx, fn in enumerate(FEATURE_NAMES, 1):
        print(f"  [{idx:02d}] {fn}")
    print("=" * 70)

if __name__ == "__main__":
    main()
