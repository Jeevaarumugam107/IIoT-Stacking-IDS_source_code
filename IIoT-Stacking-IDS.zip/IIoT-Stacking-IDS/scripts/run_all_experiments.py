"""
Master Unified Pipeline Runner
Executes scripts 01 through 08 in sequence.
"""
import os
import sys
import subprocess

SCRIPTS = [
    "01_verify_leakage_safe_partitioning.py",
    "02_run_nsga2_feature_selection.py",
    "03_train_and_evaluate_baselines.py",
    "04_train_and_evaluate_deep_learning.py",
    "05_evaluate_diversity_and_stacking.py",
    "06_run_calibration_ablation.py",
    "07_run_generalization_and_shap_diagnosis.py",
    "08_generate_all_figures_and_tables.py"
]

def main():
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    print("=" * 80)
    print("STARTING COMPLETE EMPIRICAL REPLICATION FOR IEEE IoT-72745-2026")
    print("=" * 80)
    
    for s in SCRIPTS:
        p = os.path.join(scripts_dir, s)
        print(f"\n>>> EXECUTING: {s} ...\n")
        res = subprocess.run([sys.executable, p], cwd=scripts_dir)
        if res.returncode != 0:
            print(f"Error executing {s}, exited with return code {res.returncode}")
            sys.exit(res.returncode)
            
    print("\n" + "=" * 80)
    print("SUCCESS: ALL EXPERIMENTS, AUDITS, AND VERIFICATIONS COMPLETED SUCCESSFULLY!")
    print("=" * 80)

if __name__ == "__main__":
    main()
