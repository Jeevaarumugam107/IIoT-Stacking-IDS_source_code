"""
Script 05: Diversity Evaluation & Heterogeneous Stacking Ensemble (Algorithm 3)
Computes pairwise diversity matrices, executes greedy diversity selection, and trains meta-learner.
"""
import sys
import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler
from sklearn.metrics import matthews_corrcoef, roc_auc_score

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from src.dataset_loader import load_benchmark_data
from src.models import get_classical_baselines
from src.stacking import (
    compute_all_diversity_matrices, greedy_diversity_selection, DiversityStackingClassifier
)
from src.metrics import compute_all_metrics
from src.statistical_tests import paired_bootstrap_test, group_permutation_test

def main():
    print("=" * 70)
    print("ALGORITHM 3: DIVERSITY-DRIVEN HETEROGENEOUS STACKING & STATISTICAL TESTING")
    print("=" * 70)
    
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    X, y, groups, folds = load_benchmark_data()
    
    # 1. Load Precomputed Out-of-Fold Predictions for 10 Candidate Models
    candidate_models = ["rbf_svm", "lightgbm", "random_forest", "catboost", "extra_trees", "linear_svm"]
    print(f"Candidate Model Pool: {candidate_models}")
    
    # Fast demonstration on fold out-of-fold predictions
    oof_preds = {}
    oof_probas = {}
    
    for name in candidate_models:
        oof_p = np.zeros(len(y))
        for k, (train_idx, val_idx) in enumerate(folds):
            scaler = RobustScaler()
            X_tr = scaler.fit_transform(X.iloc[train_idx])
            X_va = scaler.transform(X.iloc[val_idx])
            clf = get_classical_baselines()[name]
            clf.fit(X_tr, y[train_idx])
            oof_p[val_idx] = clf.predict_proba(X_va)[:, 1]
        oof_probas[name] = oof_p
        oof_preds[name] = (oof_p >= 0.5).astype(int)
        print(f"  {name:<16}: Standalone MCC = {matthews_corrcoef(y, oof_preds[name]):.4f} | AUROC = {roc_auc_score(y, oof_probas[name]):.4f}")
        
    # 2. Compute Diversity Matrices
    models, Q, Dis, DF = compute_all_diversity_matrices(y, oof_preds)
    print("-" * 70)
    print("Pairwise Yule's Q Matrix (Negative/Lower = Higher Diversity):")
    df_q = pd.DataFrame(Q, index=models, columns=models)
    print(df_q.round(4).to_string())
    
    # 3. Greedy Diversity Selection (Algorithm 3)
    selected_ensemble = greedy_diversity_selection(models, Q, k=4)
    print("-" * 70)
    print(f"Greedy Diversity Selected 4-Member Pool: {selected_ensemble}")
    
    # 4. Fit Logistic Regression Meta-Learner on Raw OOF Probabilities
    X_meta = np.column_stack([oof_probas[m] for m in selected_ensemble])
    stacker = DiversityStackingClassifier(base_models=selected_ensemble, C=0.1, penalty="l2")
    stacker.fit_from_oof(X_meta, y)
    
    meta_probas = stacker.predict_proba(X_meta)[:, 1]
    meta_preds = stacker.predict(X_meta, threshold=0.5)
    
    m_stack = compute_all_metrics(y, meta_preds, meta_probas)
    print(f"\nPROPOSED DIVERSITY STACKING ENSEMBLE:")
    print(f"  MCC = {m_stack['mcc']:.4f} | AUROC = {m_stack['auroc']:.4f} | Specificity = {m_stack['specificity']:.4f}")
    
    # 5. Compare with Standalone RBF-SVM (Best Single Model)
    best_single_p = oof_preds["rbf_svm"]
    diff_mcc, ci_low, ci_high, p_boot = paired_bootstrap_test(y, meta_preds, best_single_p, n_resamples=500)
    print("-" * 70)
    print("Paired Bootstrap Statistical Difference vs. Best Baseline (RBF-SVM):")
    print(f"  Delta MCC: +{diff_mcc:.4f} | 95% CI: [{ci_low:.4f}, {ci_high:.4f}] | Paired Bootstrap p-value: {p_boot:.5f}")
    
    diff_grp, p_group, _ = group_permutation_test(y, meta_preds, best_single_p, groups, n_resamples=200)
    print(f"  Group-Level Permutation Test: Delta MCC = +{diff_grp:.4f} | Group-Aware p-value: {p_group:.4f}")
    print("=" * 70)

if __name__ == "__main__":
    main()
