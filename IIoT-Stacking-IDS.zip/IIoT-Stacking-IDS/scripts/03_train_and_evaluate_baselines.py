"""
Script 03: Train and Evaluate Classical Machine Learning Baselines
Executes 5-fold cross-validation on the 14 NSGA-II features.
"""
import sys
import os
import time
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from src.dataset_loader import load_benchmark_data
from src.models import get_classical_baselines
from src.metrics import compute_all_metrics

def main():
    print("=" * 70)
    print("EXPERIMENT 1: 5-FOLD CV OF CLASSICAL BASELINE MODELS")
    print("=" * 70)
    
    X, y, groups, folds = load_benchmark_data()
    models = get_classical_baselines()
    
    # We evaluate representative models across folds
    eval_models = ["rbf_svm", "lightgbm", "random_forest", "catboost"]
    print(f"Evaluating core diverse models: {eval_models} across 5 folds...")
    
    all_results = []
    for model_name in eval_models:
        print(f"\n--> Training Model: {model_name.upper()}...")
        fold_mccs = []
        fold_aurocs = []
        t0 = time.time()
        
        for k, (train_idx, val_idx) in enumerate(folds):
            scaler = RobustScaler()
            X_tr = scaler.fit_transform(X.iloc[train_idx])
            X_va = scaler.transform(X.iloc[val_idx])
            y_tr = y[train_idx]
            y_va = y[val_idx]
            
            clf = get_classical_baselines()[model_name]
            clf.fit(X_tr, y_tr)
            
            y_proba = clf.predict_proba(X_va)[:, 1]
            y_pred = (y_proba >= 0.5).astype(int)
            
            m = compute_all_metrics(y_va, y_pred, y_proba)
            fold_mccs.append(m["mcc"])
            fold_aurocs.append(m["auroc"])
            
        elapsed = time.time() - t0
        mean_mcc, std_mcc = np.mean(fold_mccs), np.std(fold_mccs)
        mean_auroc, std_auroc = np.mean(fold_aurocs), np.std(fold_aurocs)
        print(f"  {model_name}: MCC = {mean_mcc:.4f} +/- {std_mcc:.4f} | AUROC = {mean_auroc:.4f} +/- {std_auroc:.4f} | Time: {elapsed:.1f}s")
        all_results.append({
            "model": model_name, "mean_mcc": mean_mcc, "std_mcc": std_mcc,
            "mean_auroc": mean_auroc, "std_auroc": std_auroc
        })
        
    print("-" * 70)
    print("Summary of Classical Baselines on 5-Fold Leakage-Safe CV:")
    df_res = pd.DataFrame(all_results)
    print(df_res.to_string(index=False))
    print("=" * 70)

if __name__ == "__main__":
    main()
